using System;
using System.Linq;
using System.Windows.Forms;
using ObrazPlus.Models;

namespace ObrazPlus
{
    public partial class FormMaterialProducts : Form
    {
        private readonly int materialId;

        public FormMaterialProducts(int materialId)
        {
            InitializeComponent();
            this.materialId = materialId;
        }

        private void FormMaterialProducts_Load(object sender, EventArgs e)
        {
            try
            {
                using (var context = new warehouse_dbEntities())
                {
                    var data = context.material_products
                        .Where(mp => mp.material_id == materialId)
                        .Select(mp => new
                        {
                            ProductName = mp.products.product_name,
                            RequiredQuantity = mp.required_quantity
                        })
                        .ToList();
                    dgvProducts.DataSource = data;
                }
                // Resize form based on DataGridView content
                dgvProducts.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                dgvProducts.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
                int totalWidth = dgvProducts.RowHeadersVisible ? dgvProducts.RowHeadersWidth : 0;
                foreach (DataGridViewColumn col in dgvProducts.Columns)
                    totalWidth += col.Width;
                if (dgvProducts.Rows.Count > dgvProducts.DisplayedRowCount(false))
                    totalWidth += SystemInformation.VerticalScrollBarWidth;
                int totalHeight = dgvProducts.ColumnHeadersHeight;
                foreach (DataGridViewRow row in dgvProducts.Rows)
                    totalHeight += row.Height;
                this.ClientSize = new System.Drawing.Size(totalWidth, panelHeader.Height + totalHeight);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке списка продукции: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
} 