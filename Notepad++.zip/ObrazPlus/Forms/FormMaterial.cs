using System;
using System.Linq;
using System.Windows.Forms;
using ObrazPlus.Models;

namespace ObrazPlus
{
    public partial class FormMaterial : Form
    {
        private int? materialId;
        private bool isEdit;

        public FormMaterial()
        {
            InitializeComponent();
            isEdit = false;
            this.Text = "Добавить материал";
            lblHeader.Text = "Добавить материал";
        }

        public FormMaterial(int id) : this()
        {
            materialId = id;
            isEdit = true;
            this.Text = "Редактировать материал";
            lblHeader.Text = "Редактировать материал";
        }

        private void FormMaterial_Load(object sender, EventArgs e)
        {
            // Load material types for selection
            try
            {
                using (var context = new warehouse_dbEntities())
                {
                    cbMaterialType.DataSource = context.material_types.ToList();
                    cbMaterialType.DisplayMember = "material_type_name";
                    cbMaterialType.ValueMember = "material_type_id";
                }
                // If editing, load existing data
                if (isEdit && materialId.HasValue)
                {
                    LoadMaterialData(materialId.Value);
                }
                txtName.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadMaterialData(int id)
        {
            // Retrieve material data from the database
            try
            {
                using (var context = new warehouse_dbEntities())
                {
                    var m = context.materials.Find(id);
                    if (m == null)
                        throw new InvalidOperationException("Материал не найден.");

                    cbMaterialType.SelectedValue = m.material_type_id;
                    txtName.Text = m.material_name;
                    nudUnitPrice.Value = m.unit_price;
                    txtUnitOfMeasure.Text = m.unit_of_measure;
                    nudPackageQuantity.Value = m.package_quantity;
                    nudStockQuantity.Value = m.stock_quantity;
                    nudMinQuantity.Value = m.min_quantity;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке материала: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            // Close the form without saving
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            // Validate user input
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите наименование материала.",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            if (nudUnitPrice.Value < 0)
            {
                MessageBox.Show("Цена не может быть отрицательной.",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nudUnitPrice.Focus();
                return;
            }
            if (nudMinQuantity.Value < 0)
            {
                MessageBox.Show("Минимальное количество не может быть отрицательным.",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nudMinQuantity.Focus();
                return;
            }

            try
            {
                using (var context = new warehouse_dbEntities())
                {
                    materials mat;
                    if (isEdit && materialId.HasValue)
                    {
                        mat = context.materials.Find(materialId.Value);
                        if (mat == null)
                            throw new InvalidOperationException("Материал не найден.");
                    }
                    else
                    {
                        mat = new materials();
                        context.materials.Add(mat);
                    }

                    mat.material_type_id = (int)cbMaterialType.SelectedValue;
                    mat.material_name = txtName.Text.Trim();
                    mat.unit_price = nudUnitPrice.Value;
                    mat.unit_of_measure = txtUnitOfMeasure.Text.Trim();
                    mat.package_quantity = nudPackageQuantity.Value;
                    mat.stock_quantity = nudStockQuantity.Value;
                    mat.min_quantity = nudMinQuantity.Value;

                    context.SaveChanges();
                }

                // Indicate successful save and close
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении материала: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
} 