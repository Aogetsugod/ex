namespace ObrazPlus
{
    partial class FormMaterial
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cbMaterialType;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblUnitPrice;
        private System.Windows.Forms.NumericUpDown nudUnitPrice;
        private System.Windows.Forms.Label lblUnitOfMeasure;
        private System.Windows.Forms.TextBox txtUnitOfMeasure;
        private System.Windows.Forms.Label lblPackageQuantity;
        private System.Windows.Forms.NumericUpDown nudPackageQuantity;
        private System.Windows.Forms.Label lblStockQuantity;
        private System.Windows.Forms.NumericUpDown nudStockQuantity;
        private System.Windows.Forms.Label lblMinQuantity;
        private System.Windows.Forms.NumericUpDown nudMinQuantity;
        private System.Windows.Forms.Button btnSave;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">true если управляемый ресурс должен быть удален; иначе false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMaterial));
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.cbMaterialType = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblUnitPrice = new System.Windows.Forms.Label();
            this.nudUnitPrice = new System.Windows.Forms.NumericUpDown();
            this.lblUnitOfMeasure = new System.Windows.Forms.Label();
            this.txtUnitOfMeasure = new System.Windows.Forms.TextBox();
            this.lblPackageQuantity = new System.Windows.Forms.Label();
            this.nudPackageQuantity = new System.Windows.Forms.NumericUpDown();
            this.lblStockQuantity = new System.Windows.Forms.Label();
            this.nudStockQuantity = new System.Windows.Forms.NumericUpDown();
            this.lblMinQuantity = new System.Windows.Forms.Label();
            this.nudMinQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudUnitPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPackageQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStockQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(208)))), ((int)(((byte)(255)))));
            this.panelHeader.Controls.Add(this.lblHeader);
            this.panelHeader.Controls.Add(this.btnBack);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(400, 50);
            this.panelHeader.TabIndex = 15;
            // 
            // lblHeader
            // 
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHeader.Font = new System.Drawing.Font("Constantia", 14F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(71)))), ((int)(((byte)(107)))));
            this.lblHeader.Location = new System.Drawing.Point(100, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(300, 50);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "Добавить материал";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(71)))), ((int)(((byte)(107)))));
            this.btnBack.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Constantia", 10F);
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 50);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // lblType
            // 
            this.lblType.Location = new System.Drawing.Point(10, 60);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(150, 20);
            this.lblType.TabIndex = 14;
            this.lblType.Text = "Тип материала:";
            // 
            // cbMaterialType
            // 
            this.cbMaterialType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMaterialType.Location = new System.Drawing.Point(170, 60);
            this.cbMaterialType.Name = "cbMaterialType";
            this.cbMaterialType.Size = new System.Drawing.Size(200, 23);
            this.cbMaterialType.TabIndex = 13;
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(10, 100);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(150, 20);
            this.lblName.TabIndex = 12;
            this.lblName.Text = "Наименование:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(170, 100);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 24);
            this.txtName.TabIndex = 11;
            // 
            // lblUnitPrice
            // 
            this.lblUnitPrice.Location = new System.Drawing.Point(10, 140);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new System.Drawing.Size(150, 20);
            this.lblUnitPrice.TabIndex = 10;
            this.lblUnitPrice.Text = "Цена за единицу:";
            // 
            // nudUnitPrice
            // 
            this.nudUnitPrice.DecimalPlaces = 2;
            this.nudUnitPrice.Location = new System.Drawing.Point(170, 140);
            this.nudUnitPrice.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudUnitPrice.Name = "nudUnitPrice";
            this.nudUnitPrice.Size = new System.Drawing.Size(200, 24);
            this.nudUnitPrice.TabIndex = 9;
            this.nudUnitPrice.ThousandsSeparator = true;
            // 
            // lblUnitOfMeasure
            // 
            this.lblUnitOfMeasure.Location = new System.Drawing.Point(10, 180);
            this.lblUnitOfMeasure.Name = "lblUnitOfMeasure";
            this.lblUnitOfMeasure.Size = new System.Drawing.Size(150, 20);
            this.lblUnitOfMeasure.TabIndex = 8;
            this.lblUnitOfMeasure.Text = "Ед. измерения:";
            // 
            // txtUnitOfMeasure
            // 
            this.txtUnitOfMeasure.Location = new System.Drawing.Point(170, 180);
            this.txtUnitOfMeasure.Name = "txtUnitOfMeasure";
            this.txtUnitOfMeasure.Size = new System.Drawing.Size(200, 24);
            this.txtUnitOfMeasure.TabIndex = 7;
            // 
            // lblPackageQuantity
            // 
            this.lblPackageQuantity.Location = new System.Drawing.Point(10, 220);
            this.lblPackageQuantity.Name = "lblPackageQuantity";
            this.lblPackageQuantity.Size = new System.Drawing.Size(150, 20);
            this.lblPackageQuantity.TabIndex = 6;
            this.lblPackageQuantity.Text = "Кол-во в упаковке:";
            // 
            // nudPackageQuantity
            // 
            this.nudPackageQuantity.DecimalPlaces = 2;
            this.nudPackageQuantity.Location = new System.Drawing.Point(170, 220);
            this.nudPackageQuantity.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudPackageQuantity.Name = "nudPackageQuantity";
            this.nudPackageQuantity.Size = new System.Drawing.Size(200, 24);
            this.nudPackageQuantity.TabIndex = 5;
            // 
            // lblStockQuantity
            // 
            this.lblStockQuantity.Location = new System.Drawing.Point(10, 260);
            this.lblStockQuantity.Name = "lblStockQuantity";
            this.lblStockQuantity.Size = new System.Drawing.Size(150, 20);
            this.lblStockQuantity.TabIndex = 4;
            this.lblStockQuantity.Text = "На складе:";
            // 
            // nudStockQuantity
            // 
            this.nudStockQuantity.DecimalPlaces = 2;
            this.nudStockQuantity.Location = new System.Drawing.Point(170, 260);
            this.nudStockQuantity.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudStockQuantity.Name = "nudStockQuantity";
            this.nudStockQuantity.Size = new System.Drawing.Size(200, 24);
            this.nudStockQuantity.TabIndex = 3;
            // 
            // lblMinQuantity
            // 
            this.lblMinQuantity.Location = new System.Drawing.Point(10, 300);
            this.lblMinQuantity.Name = "lblMinQuantity";
            this.lblMinQuantity.Size = new System.Drawing.Size(150, 20);
            this.lblMinQuantity.TabIndex = 2;
            this.lblMinQuantity.Text = "Мин. количество:";
            // 
            // nudMinQuantity
            // 
            this.nudMinQuantity.DecimalPlaces = 2;
            this.nudMinQuantity.Location = new System.Drawing.Point(170, 300);
            this.nudMinQuantity.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudMinQuantity.Name = "nudMinQuantity";
            this.nudMinQuantity.Size = new System.Drawing.Size(200, 24);
            this.nudMinQuantity.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(71)))), ((int)(((byte)(107)))));
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Constantia", 10F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(170, 340);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // FormMaterial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(400, 400);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.nudMinQuantity);
            this.Controls.Add(this.lblMinQuantity);
            this.Controls.Add(this.nudStockQuantity);
            this.Controls.Add(this.lblStockQuantity);
            this.Controls.Add(this.nudPackageQuantity);
            this.Controls.Add(this.lblPackageQuantity);
            this.Controls.Add(this.txtUnitOfMeasure);
            this.Controls.Add(this.lblUnitOfMeasure);
            this.Controls.Add(this.nudUnitPrice);
            this.Controls.Add(this.lblUnitPrice);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.cbMaterialType);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.panelHeader);
            this.Font = new System.Drawing.Font("Constantia", 10F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "FormMaterial";
            this.Text = "Добавить материал";
            this.Load += new System.EventHandler(this.FormMaterial_Load);
            this.panelHeader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudUnitPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPackageQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStockQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
} 