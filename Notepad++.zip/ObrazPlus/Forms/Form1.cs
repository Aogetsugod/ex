﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using ObrazPlus.Models;

namespace ObrazPlus
{
    public partial class Form1 : Form
    {
        // Выбранный материал для просмотра продукции
        private int? selectedMaterialId;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadMaterials();
        }

        private void LoadMaterials()
        {
            // Очищаем контейнер и загружаем материалы с типом
            flpMaterials.Controls.Clear();
            using (var context = new warehouse_dbEntities())
            {
                var materialsList = context.materials.Include(m => m.material_types).ToList();
                foreach (var m in materialsList)
                {
                    var required = CalculateRequiredQuantity(m.material_id);
                    var panel = new Panel
                    {
                        BorderStyle = BorderStyle.FixedSingle,
                        Width = flpMaterials.ClientSize.Width - 25,
                        Height = 100,
                        Margin = new Padding(5),
                        Tag = m.material_id
                    };
                    panel.Click += MaterialPanel_Click;
                    panel.DoubleClick += MaterialPanel_DoubleClick;
                    var lblTop = new Label
                    {
                        Text = $"{m.material_types.material_type_name} | {m.material_name}",
                        Font = new Font("Constantia", 12F, FontStyle.Bold),
                        Location = new Point(5, 5),
                        Size = new Size(panel.Width - 110, 25)
                    };
                    var lblReq = new Label
                    {
                        Text = required.ToString("F2"),
                        Font = new Font("Constantia", 12F, FontStyle.Bold),
                        Location = new Point(panel.Width - 100, 5),
                        Size = new Size(95, 25),
                        TextAlign = ContentAlignment.MiddleRight
                    };
                    var lblMin = new Label
                    {
                        Text = $"Минимальное количество: {m.min_quantity}",
                        Font = new Font("Constantia", 10F),
                        Location = new Point(5, 35),
                        AutoSize = true
                    };
                    var lblStock = new Label
                    {
                        Text = $"Количество на складе: {m.stock_quantity}",
                        Font = new Font("Constantia", 10F),
                        Location = new Point(5, 55),
                        AutoSize = true
                    };
                    var lblPrice = new Label
                    {
                        Text = $"Цена: {m.unit_price} р/{m.unit_of_measure} | {m.package_quantity}",
                        Font = new Font("Constantia", 10F),
                        Location = new Point(5, 75),
                        AutoSize = true
                    };
                    panel.Controls.Add(lblTop);
                    panel.Controls.Add(lblReq);
                    panel.Controls.Add(lblMin);
                    panel.Controls.Add(lblStock);
                    panel.Controls.Add(lblPrice);
                    flpMaterials.Controls.Add(panel);
                }
            }
        }

        // Обработчик клика по панели материала
        private void MaterialPanel_Click(object sender, EventArgs e)
        {
            if (sender is Panel panel && panel.Tag is int id)
            {
                selectedMaterialId = id;
                foreach (Panel p in flpMaterials.Controls)
                {
                    p.BackColor = Color.White;
                }
                panel.BackColor = Color.FromArgb(230, 240, 255);
            }
        }

        // Редактировать материал при двойном клике на карточке
        private void MaterialPanel_DoubleClick(object sender, EventArgs e)
        {
            if (sender is Panel panel && panel.Tag is int id)
            {
                try
                {
                    using (var form = new FormMaterial(id))
                    {
                        if (form.ShowDialog() == DialogResult.OK)
                        {
                            LoadMaterials();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при редактировании материала: " + ex.Message,
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private decimal CalculateRequiredQuantity(int materialId)
        {
            using (var context = new warehouse_dbEntities())
            {
                var total = context.material_products
                    .Where(mp => mp.material_id == materialId)
                    .Sum(mp => (decimal?)mp.required_quantity) ?? 0m;
                return Math.Round(total, 2);
            }
        }

        // Открыть форму для добавления нового материала
        private void BtnAddMaterial_Click(object sender, EventArgs e)
        {
            try
            {
                using (var form = new FormMaterial())
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadMaterials();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при открытии формы: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Открыть список продукции для выбранного материала
        private void BtnViewProducts_Click(object sender, EventArgs e)
        {
            if (!selectedMaterialId.HasValue)
            {
                MessageBox.Show("Выберите материал.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (var form = new FormMaterialProducts(selectedMaterialId.Value))
                {
                    form.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при открытии списка продукции: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
