using System;
using System.Linq;
using System.Data.Entity;
using ObrazPlus.Models;

namespace ObrazPlus
{
    public static class CalculationHelper
    {
        /// <summary>
        /// Рассчитывает количество продукции, которое можно получить из заданного количества сырья с учетом потерь.
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции.</param>
        /// <param name="materialTypeId">Идентификатор типа сырья.</param>
        /// <param name="rawQuantity">Количество сырья (целое число).</param>
        /// <param name="param1">Параметр продукции 1 (вещественное, положительное число).</param>
        /// <param name="param2">Параметр продукции 2 (вещественное, положительное число).</param>
        /// <returns>Количество продукции (целое число) или -1 при ошибке.</returns>
        public static int CalculateProductCount(int productTypeId, int materialTypeId, int rawQuantity, double param1, double param2)
        {
            if (rawQuantity < 0 || param1 <= 0 || param2 <= 0)
                return -1;

            try
            {
                using (var context = new warehouse_dbEntities())
                {
                    var productType = context.product_types.Find(productTypeId);
                    var materialType = context.material_types.Find(materialTypeId);
                    if (productType == null || materialType == null)
                        return -1;

                    double coefficient = (double)productType.type_coefficient;
                    double lossPercentage = (double)materialType.loss_percentage;

                    double requiredPerUnit = param1 * param2 * coefficient;
                    if (requiredPerUnit <= 0)
                        return -1;

                    double effectiveRaw = rawQuantity * (1 - lossPercentage / 100.0);
                    if (effectiveRaw < requiredPerUnit)
                        return 0;

                    return (int)Math.Floor(effectiveRaw / requiredPerUnit);
                }
            }
            catch
            {
                return -1;
            }
        }
    }
} 